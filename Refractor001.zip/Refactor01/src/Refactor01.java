/**
 * Ejemplo de c�digo Java Repetido
 * 
 * @author      Paco Gomez <fjgomez@florida-uni.es>
 * @version     1.0 
 * @since       1.2          (the version of the package this class was first added to)
 */
public class Refactor01 {

    public static void main(String[] args) {
        float area;
        //Calculador de areas
        //Cuadrado
        int lado=3;
        area=lado*lado;
        
        String titulo = "CUADRADO";
        muestra(titulo, area);
        
        //Circulo
        float pi=3.14f;
        int radio=3;
        area=pi*radio*radio;

        titulo = "CIRCULO";
        muestra(titulo, area);
        //Cuadrado
        int base=3;
        int altura=6;
        area=base*altura;
        
        titulo = "RECTANGULO";
        muestra(titulo, area);
    }
    public static void muestra(String titulo, float valor)
    {
        System.out.println("---- AREA DE UN "+titulo+" ------");
        System.out.println(valor);
        System.out.println("-------------------------------");
    }
}